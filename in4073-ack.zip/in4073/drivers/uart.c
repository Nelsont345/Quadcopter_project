/*------------------------------------------------------------------
 *  uart.c -- configures uart
 *
 *  I. Protonotarios
 *  Embedded Software Lab
 *
 *  July 2016
 *------------------------------------------------------------------
 */

#include "in4073.h"

bool txd_available = true;

int8_t counter = 0;
int8_t packet_size;
int8_t current_data;
bool start_flag = false;

void uart_put(uint8_t byte)
{
	NVIC_DisableIRQ(UART0_IRQn);

	if (txd_available) {txd_available = false; NRF_UART0->TXD = byte;}
	else enqueue(&tx_queue, byte);

	NVIC_EnableIRQ(UART0_IRQn);
}

// Reroute printf
int _write(int file, const char * p_char, int len)
{
	int i;
	for (i = 0; i < len; i++)
	{
		uart_put(*p_char++);
	}
	return len;
}


void UART0_IRQHandler(void)
{    // printf("in irq\n");  
     //   printf("%ld\n", NRF_UART0->EVENTS_RXDRDY);
/*	if (NRF_UART0->EVENTS_RXDRDY != 0)
	{       printf("received\n");
		NRF_UART0->EVENTS_RXDRDY  = 0;
		enqueue( &rx_queue, NRF_UART0->RXD);
	}
*/

        if (NRF_UART0->EVENTS_RXDRDY != 0)
	{       printf("\n\n\nin if 1\n");

                NRF_UART0->EVENTS_RXDRDY  = 0;

                current_data = NRF_UART0->RXD;
                printf("received: %d\n", current_data);

                if(current_data == 61)
                {   start_flag = 1;
                    printf("in if 2334\n");
                    packet_size = PACKET_SIZE1;
                    //printf("setting start flag 2\n");
                    counter = 0;
                }

                else if(current_data == 47) 
                {   start_flag = 1;
                    printf("in if 2\n");
                    packet_size = PACKET_SIZE2;
                    //printf("setting start flag\n");
                    counter = 0;
                   // uart_put(52);
                }

                if(start_flag == 1 && counter < packet_size)
                {
                    //enqueue( &rx_queue, NRF_UART0->RXD);
                    enqueue( &rx_queue, current_data);
                    printf("enqueueing\n");
                    if(counter == (packet_size - 1))
                    {  // printf("packet full");
                        counter = 0;
                        start_flag = 0;
                        uart_put(44);
                        uart_put(44);   // should send the crc/error message instead 
                    }
                    counter++;                       
                }  		
	}




	if (NRF_UART0->EVENTS_TXDRDY != 0)
	{
		NRF_UART0->EVENTS_TXDRDY = 0;
		if (tx_queue.count) NRF_UART0->TXD = dequeue(&tx_queue);
		else txd_available = true;
	}

	if (NRF_UART0->EVENTS_ERROR != 0)
	{
		NRF_UART0->EVENTS_ERROR = 0;
		printf("uart error: %lu\n", NRF_UART0->ERRORSRC);
	}
}


void uart_init(void)
{
	init_queue(&rx_queue); // Initialize receive queue
	init_queue(&tx_queue); // Initialize transmit queue

	nrf_gpio_cfg_output(TX_PIN_NUMBER);
	nrf_gpio_cfg_input(RX_PIN_NUMBER, NRF_GPIO_PIN_NOPULL); 
	NRF_UART0->PSELTXD = TX_PIN_NUMBER;
	NRF_UART0->PSELRXD = RX_PIN_NUMBER;
	NRF_UART0->BAUDRATE        = (UART_BAUDRATE_BAUDRATE_Baud115200 << UART_BAUDRATE_BAUDRATE_Pos);

	NRF_UART0->ENABLE           = (UART_ENABLE_ENABLE_Enabled << UART_ENABLE_ENABLE_Pos);
	NRF_UART0->EVENTS_RXDRDY    = 0;
	NRF_UART0->EVENTS_TXDRDY    = 0;
	NRF_UART0->TASKS_STARTTX    = 1;
	NRF_UART0->TASKS_STARTRX    = 1;

	NRF_UART0->INTENCLR = 0xffffffffUL;
	NRF_UART0->INTENSET = 	(UART_INTENSET_RXDRDY_Set << UART_INTENSET_RXDRDY_Pos) |
                          	(UART_INTENSET_TXDRDY_Set << UART_INTENSET_TXDRDY_Pos) |
                          	(UART_INTENSET_ERROR_Set << UART_INTENSET_ERROR_Pos);

	NVIC_ClearPendingIRQ(UART0_IRQn);
	NVIC_SetPriority(UART0_IRQn, 3); // either 1 or 3, 3 being low. (sd present)
	NVIC_EnableIRQ(UART0_IRQn);
}
