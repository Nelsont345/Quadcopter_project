/*------------------------------------------------------------------
 *  in4073.c -- test QR engines and sensors
 *
 *  reads ae[0-3] uart rx queue
 *  (q,w,e,r increment, a,s,d,f decrement)
 *
 *  prints timestamp, ae[0-3], sensors to uart tx queue
 *
 *  I. Protonotarios
 *  Embedded Software Lab
 *
 *  June 2016
 *------------------------------------------------------------------
 */

#include "in4073.h"

/*------------------------------------------------------------------
 * process_key -- process command keys
 *------------------------------------------------------------------
 */
void process_key(uint8_t c)
{
	switch (c)
	{
		case 'q':
			ae[0] += 10;
			break;
		case 'a':
			ae[0] -= 10;
			if (ae[0] < 0) ae[0] = 0;
			break;
		case 'w':
			ae[1] += 10;
			break;
		case 's':
			ae[1] -= 10;
			if (ae[1] < 0) ae[1] = 0;
			break;
		case 'e':
			ae[2] += 10;
			break;
		case 'd':
			ae[2] -= 10;
			if (ae[2] < 0) ae[2] = 0;
			break;
		case 'r':
			ae[3] += 10;
			break;
		case 'f':
			ae[3] -= 10;
			if (ae[3] < 0) ae[3] = 0;
			break;
		case 27:
			demo_done = true;
			break;
		default:
			nrf_gpio_pin_toggle(RED);
	}
}

/*------------------------------------------------------------------
 * main -- everything you need is here :)
 *------------------------------------------------------------------
 */
int main(void)
{
	uart_init();
	gpio_init();
	timers_init();
	adc_init();
	twi_init();
	imu_init(true, 100);	
	baro_init();
	spi_flash_init();
	ble_init();

	uint32_t counter = 0;
	demo_done = false;
        uint8_t element;
        //uint8_t parser=0;
        //uint8_t start_parse = 0;
        uint8_t state = 0;

	while (!demo_done)
	{
		//if (rx_queue.count) process_key( dequeue(&rx_queue) );

               
                if(rx_queue.count)
                {     printf("state:%d\n", state);
                      switch(state)
                      {
                             case 99: 
                                     element = dequeue(&rx_queue);
                                     if(element == '/' || element == '=')                                     
                                         {  state = dequeue(&rx_queue); 
                                           printf("mode received:%d\n", state);}
                                    else
                                            printf("wrong element\n");                                           
                                     break;
                                                                                                
                             //safe state
                             case '0': L = 0; M = 0; N = 0; T = 0;
                                     state = 99;
                                     break;
                   
                             //panic state
                             case '1': L = 0; M = 0; N = 0; T = 1000;
                                     //wait for some time
                                     state = 0;
                                     break;

                             //manual mode
                             case '2': 
                                     L = dequeue(&rx_queue);   
                                     M = dequeue(&rx_queue);   
                                     N = dequeue(&rx_queue);   
                                     T = dequeue(&rx_queue);   
                                     state = 99;
                                     break;
 
                             default:
                                     printf("error\n");
                                     state = 99;
                                     break;
                      }
                      printf("L = %d, M = %d, N = %d, T = %d\n", L, M, N, T);
                     
                       
                }
		if (check_timer_flag()) 
		{
			if (counter++%20 == 0) nrf_gpio_pin_toggle(BLUE);

			adc_request_sample();
			read_baro();

			/*printf("%10ld | ", get_time_us());
			printf("%3d %3d %3d %3d | ",ae[0],ae[1],ae[2],ae[3]);
			printf("%6d %6d %6d | ", phi, theta, psi);
			printf("%6d %6d %6d | ", sp, sq, sr);
			printf("%4d | %4ld | %6ld \n", bat_volt, temperature, pressure);
*/
			clear_timer_flag();
		}

		if (check_sensor_int_flag()) 
		{
			get_dmp_data();
			run_filters_and_control();
		}
	}	

	printf("\n\t Goodbye \n\n");
	nrf_delay_ms(100);

	NVIC_SystemReset();
}
